
#include <tchar.h>  // #include <- dolaczenie danej biblioteki do projektu
#include <stdio.h>
#include <conio.h>
#include <iostream>

using namespace std; // wskazanie na uzycie przestrzeni nazw std

int _tmain(int argc, _TCHAR* argv[]) // poczatek programu -> funkcja tmain()
{
	cout << "Hello world!" << endl; // przeslanie na ekran tekstu "Hello world!" za pomoca funkcji cout

	getch(); // oczekiwanie na klikniecie klawisza - w tym przypadku sluzy do zatrzymania na chwile programu

	return 0;
}
