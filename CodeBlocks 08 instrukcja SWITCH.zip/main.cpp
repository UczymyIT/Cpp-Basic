/*--------------------------------------------------------------
���Program nr 8
���Instrukcja: switch
--------------------------------------------------------------
Co ma robic program:

1. popros uzytkownika o podanie dnia tygodnia w postaci liczby
2. zapisz liczbe do zmiennej
3. w zaleznosci od podanej liczby wyswietl uzytkownikowi informacje jaki to dzien
    wykorzystaj do tego instrukcje swithc
--------------------------------------------------------------*/

#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj dzien tygodnia: " ;
    int dzien;
    cin >> dzien;

    switch (dzien) {
      case 1:
        cout << "Poniedzielek";
        break;
      case 2:
        cout << "Wtorek";
        break;
      case 3:
        cout << "Sroda";
        break;
      case 4:
        cout << "Czwartek";
        //cout << endl << "Pamietaj masz karate!";
        //cout << endl << "Pamietaj idz do sklepu";
        break;
      case 5:
        cout << "Piatek";
        break;
      case 6:
        cout << "Sobota";
        break;
      case 7:
        cout << "Niedziela";
        break;
    }

    return 0;
}
