#include <iostream>
#include <string>
#include <conio.h>
using namespace std;

int _tmain()
{
	cout << "Podaj swoje imie: " ;
	string imie;
	cin >> imie;
	cout << "Czesc " << imie << " milo Cie poznac.";
    getch();
	return 0;
}
