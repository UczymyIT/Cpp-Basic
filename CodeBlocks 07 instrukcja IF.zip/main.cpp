/*--------------------------------------------------------------
���Program nr 7
���Instrukcja warunkowa: if
--------------------------------------------------------------
Co ma robic program:

Wyswietl pytanie o wyb�r dzialania arytmetycznego. Uzytkownik ma podac : "+" lub "-" lub "*" lub "/"
Zapisz podany znak do zmiennej o nazwie: "dzialanie".
Wygeneruj dwie liczby losowe z zakresu od 0-100 i zapisz je do zmiennych: "a" i "b".
Wyswietl komunikat na ekranie: "Podaj wynik dzialania: wartosc_zmiennej_a znak_dzialania wartosc_zmiennej_b = ".
Pobierz od uzytkownika wynik i zapisz go do zmiennej o nazwie "wynik".
Sprawdz czy podany przez uzytkownika wynik jest poprawny.
W zaleznosci czy wynik jest poprawny czy bledny wyswietl odpowiedni komunikat uzytkownikowi.

Podpowiedz:

Do wygenerowania liczby losowej wykorzystaj funkcje rand()
W tym celu na poczatku programu dodaj linie: srand( time( NULL ) );
a wygenerowanie liczby losowej, z zakresu do 100, wyglada tak:
���int a,b;
���a = rand()% 100;
���b = rand()% 100;
--------------------------------------------------------------*/

#include <iostream>
#include <ctime>

using namespace std;

int main()
{
    cout << "Wybierz dzialanie (+,-,*,/): " ;
    string dzialanie;
    cin >> dzialanie;

    srand( time( NULL ) );
    int a,b;
    a = rand()% 100;
    b = rand()% 100;

    cout << "Podaj wynik dzialania: " << a << dzialanie << b << " = " ;
    int wynik;
    cin >> wynik;

    if(dzialanie == "+")
    {
       if((a+b) == wynik)
            cout << "Brawo. Widac ze znasz sie na dodawaniu";
        else
            cout << "Niestety Twoja odpowiedz jest bledna. Pocwicz dodawanie.";
    }
    if(dzialanie == "-")
    {
       if((a-b) == wynik)
            cout << "Brawo. Widac ze znasz sie na odejmowaniu";
        else
            cout << "Niestety Twoja odpowiedz jest bledna. Pocwicz odejmowanie.";
    }
    if(dzialanie == "*")
    {
       if((a*b) == wynik)
            cout << "Brawo. Widac ze znasz sie na mnozeniu";
        else
            cout << "Niestety Twoja odpowiedz jest bledna. Pocwicz mnozenie.";
    }
    if(dzialanie == "/")
    {
       if((a/b) == wynik)
            cout << "Brawo. Widac ze znasz sie na dzieleniu";
        else
            cout << "Niestety Twoja odpowiedz jest bledna. Pocwicz dzielenie.";
    }


    return 0;
}
