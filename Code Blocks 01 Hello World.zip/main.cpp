#include <iostream> // dolaczenie biblioteki IOStream

using namespace std; //

int main()
{
    cout << "Hello world!" << endl; // przeslanie na ekran tekstu "Hello world!"
    return 0;
}
