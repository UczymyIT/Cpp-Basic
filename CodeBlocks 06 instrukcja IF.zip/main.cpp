/*--------------------------------------------------------------
���Program nr 6
���Instrukcja warunkowa: if
--------------------------------------------------------------
Co ma robic program:

1. Zapytac uzytkownika o imie.
2. Zapisac imie podane przez uzytkownika do zmiennej.
3. Zpytac uzytkownika o wiek.
4. Zapisac wiek uzytkownika do zmiennej.
5. W zaleznosci od danych jakie poda uzytkownik (imie i wiek), przypisz uzytkownika do odpowiedniej grupy i spraw, ze otrzyma odpowiedni komunikat.
���a. dla grupy: mezczyzna ponizej 14 lat, wyswietl komunikat: "Tresc odpowiednia dla mezczyzny ponizej 14 lat".
���b. dla grupy: mezczyzna od 15 do 17 lat, wyswietl komunikat: "Tresc odpowiednia dla mezczyzny w wieku 15-17 lat".
���c. dla grupy: mezczyzna powyzej 17 lat, wyswietl komunikat: "Tresc odpowiednia dla mezczyzny powyzej 17 lat".
���d. dla grupy: kobieta do 35 lat, wyswietl komunikat: "Tresc odpowiednia dla kobiety do 35 lat".
���e. dla grupy: kobieta powyzej 35 lat, wyswietl komunikat: "Tresc odpowiednia dla kobiety powyzej 35 lat".

Podpowied�:

1. Zidentyfikuj plec po imieniu. Imiona kobiet koncza sie na litere "a".
���Do sprawdzenia jaka jest ostatnia litera imienia mozesz skorzystac z funkcji:
���length(), kt�ra obliczy dlugosc imienia (ile imie ma znak�w)
������przyklad: int liczbaZnakow = imie.length();
���substr(), kt�ra przy odpowiednich argumentach, zwr�ci Wam ostatnia litere imienia.
������przyklad: string znak = imie.substr( od_ktorego_miejsca_wycia_znaki , ile_znak�w_wyciac )

2. Do wyswietlania odpowiedniego komunikatu dla odpowiedniej grupy uzyj instrukcji warunkowej IF.
-------------------------------------------------------------- */
#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj swoje imie: ";
    string imie;
    cin >> imie;
    int ileZnakow = imie.length();
    cout << "Imie ma : " << ileZnakow << " znakow.";
    string ostatniaLitera = imie.substr(imie.length()-1);
    //cout << "Dlugosc imienia: " << imie.length();
    //cout << "Ostatnia litera imienia to: " << ostatniaLitera;

    cout << "Podaj swoj wiek: ";
    int wiek;
    cin >> wiek;

    if(ostatniaLitera == "a" && wiek <= 35)
    {
        cout <<  "Wyswietlam tresc dla kobiet do 35 lat";
    }
    else if(ostatniaLitera == "a" && wiek > 35)
        {
            cout <<  "Wyswietlam tresc dla kobiet powyzej 35 lat";
        }
    if(ostatniaLitera != "a" && wiek < 14)
    {
        cout <<  "Wyswietlam tresc dla mezczyzn ponizej 14 lat";
    }
    else if(ostatniaLitera != "a" && wiek >= 15 && wiek <= 17)
        {
            cout <<  "Wyswietlam tresc dla mezczyzn od 15 do 17 lat";
        }
        else if(ostatniaLitera != "a" && wiek > 17)
        {
            cout <<  "Wyswietlam tresc dla mezczyzn powyzej 17 lat";
        }

    return 0;
}
