/* --------------------------------------------------------------
���Program nr 5
���Instrukcja warunkowa: if
--------------------------------------------------------------
Co ma robi� program:

1. Popros uzytkownika o podanie 3 liczb.
2. Za pomoca instrukcji IF sprawdz ktora z podanych liczb jest najwieksza.
3. Wyswietl ta liczbe na ekranie monitora.
-------------------------------------------------------------- */

#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj liczby: " << endl;
    int a,b,c,x;
    cin >> a >> b >> c ;
    x = a;
    if(x < b)
    {
        x = b;
    }
    if (x < c)
    {
        x = c;
    }

    cout << "Najwieksza liczba to: " << x ;

    return 0;
}
