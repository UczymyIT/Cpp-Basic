//---------------------------------------------------------------------------
#include <System.JSON.hpp>

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
	DBGrid1->DataSource = DataSource1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	ShowMessage("Wcisn��e� przycisk");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormShow(TObject *Sender)
{
	String sql = "SELECT slowkopolskie AS \"S��wko Polskie\", slowkoangielskie AS \"S��wko Angielskie\", nazwa AS \"Nazwa kategorii\"  FROM slowka JOIN kategorie ON slowka.idkategoria = kategorie.id";
	wykonaj_sql(FDQuery1, sql, "ActiveType");
	wypelnij_combo_kategorie(cboxKategorie);
//	FDQuery1->SQL->Text =
//	FDQuery1->Open();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::wypelnij_combo_kategorie(TComboBox* cboxObject)
{
	String sql = "SELECT * FROM kategorie ORDER BY kategorie.nazwa";
	wykonaj_sql(FDQTemp, sql, "ActiveType");
	TJSONObject* jsonData = new TJSONObject;
	wgraj_slownik_kategorii_do_json(DSTemp, jsonData);
	TJSONArray* jsonArray = dynamic_cast<TJSONArray*>(jsonData->GetValue("data"));
	if(jsonArray)
	{
		for(int i = 0; i < jsonArray->Count ; i++)
		{
            TJSONObject* jsonObject = dynamic_cast<TJSONObject*>(jsonArray->Items[i]);
			if (jsonObject) {
				cboxObject->Items->Add(jsonObject->GetValue("nazwa")->Value());
			}
		}
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::wykonaj_sql(TFDQuery* query, String sql, String typ_sql)
{
	query->Active = false;
	query->SQL->Clear();
	query->SQL->Add(sql);
	if(typ_sql == "ActiveType")
	{
		query->Active = true;
	}
	else if(typ_sql == "ExecSQLType")
	{
		query->ExecSQL();
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::wgraj_slownik_kategorii_do_json(TDataSource* data_source, TJSONObject* json_data)
{
	TJSONArray* jsonArray = new TJSONArray;

	bool flaga = data_source->DataSet->FindFirst();
	while(flaga)
	{
		TJSONObject* jsonObject = new TJSONObject;
		jsonObject->AddPair("id", data_source->DataSet->FieldByName("id")->AsString);
		jsonObject->AddPair("nazwa", data_source->DataSet->FieldByName("nazwa")->AsString);
		jsonArray->AddElement(jsonObject);

		flaga = data_source->DataSet->FindNext();
	}
	json_data->AddPair("data", jsonArray);
}
//---------------------------------------------------------------------------
