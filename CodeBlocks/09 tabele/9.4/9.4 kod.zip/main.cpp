#include <iostream>

using namespace std;

int main()
{

    // deklaracja i inicjalizacja tablicy "t"
    int t[10];
    int j = 101;
    for(int i = 0 ; i<= 9 ; i++){
        t[i] = j;
        j++;
    }

    for(int i = 0 ; i<= 9 ; i++){
        cout << t[i] << endl ;
    }

    return 0;
}
