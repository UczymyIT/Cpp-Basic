#include <iostream>

using namespace std;

int main()
{
    int tab[6] = {44, 12, 86, 107, 99, 150};

    for(int i = 0 ; i <= 5 ; i++ ){
        cout << tab[i] << endl ;
    }

    return 0;
}


