#include <iostream>

using namespace std;

int main()
{

    // deklaracja i inicjalizacja tablicy "t"
    int t[9];

    for(int i = 0 ; i<= 8 ; i++){
        cin >> t[i];
    }

    cout << endl;

    for(int i = 0 ; i<= 8 ; i++){
        cout << t[i] << endl ;
    }

    return 0;
}
