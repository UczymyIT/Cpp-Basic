#include "przycisk.h"
#include <iostream>
using namespace std;

/*Przycisk::Przycisk(int szer, int wys, string text)
{
   okreslWymiaryPrzycisku(wys, wys, text);
}*/

Przycisk::okreslWymiaryPrzycisku(int sz, int w, string t)
{
    if(sz < 99 || sz > 102) cout << "Cos jest nie tak z obiektem!";
    szerokosc = sz;
    wysokosc = w;
    napis = t;
}
