#include <iostream>
#include "przycisk.h"
using namespace std;

int main()
{
    Przycisk p1;//(100,25,"To jest przycisk");

    return 0;
}
