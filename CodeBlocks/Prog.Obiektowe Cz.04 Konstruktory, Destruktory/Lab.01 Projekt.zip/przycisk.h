#include <iostream>
using namespace std;

class Przycisk
{
    public:
    int szerokosc;
    int wysokosc;
    string napis;

    //Przycisk(int szer = 90, int wys = 25, string text = "tekst");

    //Przycisk(int szer = 90, int wys = 25);

    okreslWymiaryPrzycisku(int sz, int w, string t);

};
