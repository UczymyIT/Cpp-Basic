#include <iostream>

using namespace std;

int main()
{

    if( 2+2 == 4)
    {
        cout << "Warunek jest spelniony, czyli = TRUE";
    }
    else
    {
        cout << "Warunek NIE jest spelniony, czyli = FALSE";
    }

    return 0;
}
