#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj swoje imie: ";
    string imie;
    cin >> imie;
    int ileZnakow = imie.length();
    cout << "Imie ma : " << ileZnakow << " znakow." << endl;
    string ostatniaLitera = imie.substr(imie.length()-1);
    //cout << "Dlugosc imienia: " << imie.length();
    //cout << "Ostatnia litera imienia to: " << ostatniaLitera;

    cout << "Podaj swoj wiek: ";
    int wiek;
    cin >> wiek;

    // czesc dotyczaca kobiet
    if(ostatniaLitera == "a" && wiek <= 35)
    {
        cout <<  "Wyswietlam tresc dla kobiet do 35 lat";
    }
    else if(ostatniaLitera == "a" && wiek > 35)
        {
            cout <<  "Wyswietlam tresc dla kobiet powyzej 35 lat";
        }

    // czesc dotyczaca mezczyzn
    if(ostatniaLitera != "a" && wiek < 14)
    {
        cout <<  "Wyswietlam tresc dla mezczyzn ponizej 14 lat";
    }
    else if(ostatniaLitera != "a" && wiek >= 14 && wiek <= 17)
        {
            cout <<  "Wyswietlam tresc dla mezczyzn od 14 do 17 lat";
        }
        else if(ostatniaLitera != "a" && wiek > 17)
        {
            cout <<  "Wyswietlam tresc dla mezczyzn powyzej 17 lat";
        }

    return 0;
}
