#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj 3 liczby: " << endl;
    int a,b,c,x;
    cin >> a >> b >> c ;
    x = a;
    if(x < b)
    {
        x = b;
    }
    if (x < c)
    {
        x = c;
    }

    cout << "Najwieksza liczba to: " << x ;

    return 0;
}
