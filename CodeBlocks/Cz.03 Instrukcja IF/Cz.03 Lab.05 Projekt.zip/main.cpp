#include <iostream>

using namespace std;

int main()
{
    cout << "Ktory miesiac mamy (podaj cyfre): " ;
    int liczba;
    cin >> liczba;

    if(liczba == 1)
    {
        cout << "Jest styczen";
    }
    if(liczba == 2)
    {
        cout << "Jest luty";
    }
    if(liczba == 3)
    {
        cout << "Jest marzec";
    }
    if(liczba == 4)
    {
        cout << "Jest kwiecien";
    }
    if(liczba == 5)
    {
        cout << "Jest maj";
    }
    if(liczba == 6)
    {
        cout << "Jest czerwiec";
    }
    if(liczba == 7)
    {
        cout << "Jest lipiec";
    }
    if(liczba == 8)
    {
        cout << "Jest sierpien";
    }
    if(liczba == 9)
    {
        cout << "Jest wrzesien";
    }
    if(liczba == 10)
    {
        cout << "Jest pazdziernik";
    }
    if(liczba == 11)
    {
        cout << "Jest listopad";
    }
    if(liczba == 12)
    {
        cout << "Jest grudzien";
    }
    if(liczba < 1 || liczba > 12)
    {
        cout << "Nie ma takiego miesiaca!";
    }


    return 0;
}
