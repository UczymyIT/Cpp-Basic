#include <iostream>
using namespace std;

float oceny[5];
float suma=0, srednia;

int main()
{
    for(int i=0 ; i<5 ; i++){
        cout << "Podaj ocene " << i +1 << ": ";
        cin >> oceny[i];
        suma = suma + oceny[i];
    }
    srednia = suma / 5;
    cout << "Srednia = " << srednia ;

    return 0;
}
