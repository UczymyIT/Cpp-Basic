#include <iostream>
#include <ctime>

using namespace std;

int main()
{
    cout << "Wybierz dzialanie (+,-,*,/): " ;
    string dzialanie;
    cin >> dzialanie;

    srand( time( NULL ) );
    int a,b;
    a = rand()% 100;
    b = rand()% 100;

    cout << "Podaj wynik dzialania: " << a << dzialanie << b << " = " ;
    int wynik;
    cin >> wynik;

    if(dzialanie == "+")
    {
       if((a+b) == wynik)
            cout << "Brawo. Widac ze znasz sie na dodawaniu";
        else
            cout << "Niestety Twoja odpowiedz jest bledna. Pocwicz dodawanie.";
    }
    if(dzialanie == "-")
    {
       if((a-b) == wynik)
            cout << "Brawo. Widac ze znasz sie na odejmowaniu";
        else
            cout << "Niestety Twoja odpowiedz jest bledna. Pocwicz odejmowanie.";
    }
    if(dzialanie == "*")
    {
       if((a*b) == wynik)
            cout << "Brawo. Widac ze znasz sie na mnozeniu";
        else
            cout << "Niestety Twoja odpowiedz jest bledna. Pocwicz mnozenie.";
    }
    if(dzialanie == "/")
    {
       if((a/b) == wynik)
            cout << "Brawo. Widac ze znasz sie na dzieleniu";
        else
            cout << "Niestety Twoja odpowiedz jest bledna. Pocwicz dzielenie.";
    }


    return 0;
}
