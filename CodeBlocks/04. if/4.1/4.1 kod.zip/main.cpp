#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj pierwsza liczbe : ";
    int liczba1;
    cin >> liczba1;

    cout << "Podaj druga liczbe : ";
    int liczba2;
    cin >> liczba2;

    if(liczba1 < liczba2)
        cout << "Liczba1 jest mniejsza niz liczba2";
    else
        cout << "Liczba1 NIE jest mniejsza niz liczba2";

    return 0;
}
