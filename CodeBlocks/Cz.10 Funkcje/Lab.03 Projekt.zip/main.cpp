#include <iostream>

using namespace std;
float obliczBMI(float waga, float wzrost)
{
    return waga/(wzrost*wzrost);
}

int zinterpretujWynikiBMI(float bmi)
{
    cout << "Twoje BMI wynosi: " << bmi << endl;
    if(bmi<16)
        cout << "Twoj wynik oznacza wyglodzenie.";
    else if(bmi >= 16 && bmi < 16.9)
        cout << "Twoj wynik oznacza wychudzenie.";
    else if(bmi >= 17 && bmi < 18.4)
        cout << "Twoj wynik oznacza niedowage.";
    else if(bmi >= 18.5 && bmi < 24.9)
        cout << "Twoj wynik oznacza prawidlowa wage.";
    else if(bmi >= 25 && bmi < 29.9)
        cout << "Twoj wynik oznacza nadwage.";
    else if(bmi >= 30 && bmi < 34.9)
        cout << "Twoj wynik oznacza I stopien otylosci.";
    else if(bmi >= 35 && bmi <= 40)
        cout << "Twoj wynik oznacza II stopien otylosci.";
    else if(bmi > 40)
        cout << "Twoj wynik oznacza III stopien otylosci";
}

int main()
{
    cout << "Podaj wage w kilogramach: ";
    float waga;
    cin >> waga;
    cout << "Podaj wzrost w metrach: ";
    float wzrost;
    cin >> wzrost;


    zinterpretujWynikiBMI(obliczBMI(waga,wzrost));

    return 0;
}
