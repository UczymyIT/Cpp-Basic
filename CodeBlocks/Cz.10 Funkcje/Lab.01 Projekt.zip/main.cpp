#include <iostream>

using namespace std;
void PobierziWyswielImie()
{
    cout << "Twoje imie: ";
    string imie;
    cin >> imie;
    cout << imie << endl;
}
int main()
{
    PobierziWyswielImie();

    // 100 linii kodu

    PobierziWyswielImie();

    // 100 linii kodu

    PobierziWyswielImie();

    return 0;
}

/*#include <iostream>

using namespace std;

int main()
{
    cout << "Twoje imie: ";
    string imie;
    cin >> imie;
    cout << imie << endl;

    // 100 linii kodu

    cout << "Twoje imie: ";
    cin >> imie;
    cout << imie << endl;

    // 100 linii kodu

    cout << "Twoje imie: ";
    cin >> imie;
    cout << imie << endl;

    return 0;
}*/
