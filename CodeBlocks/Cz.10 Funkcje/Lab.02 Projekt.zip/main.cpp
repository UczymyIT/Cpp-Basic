#include <iostream>

using namespace std;

    funkcja1() // <- naglowek funkcji
    {
        // cialo funkcji (kod ktory wykonuje funkcja)
        cout << "Witam z funkcji";
    }

    int funkcja2(int liczba1, int liczba2)
    {
        return liczba1 + liczba2;
    }

int main()
{

    funkcja1();

    cout << endl << "Podaj liczbe 1: ";
    int liczba1;
    cin >> liczba1;
    cout << "Podaj liczbe 2: ";
    int liczba2;
    cin >> liczba2;

    cout << "Wynik zwrocony z funkcji 2: " << funkcja2(liczba1,liczba2);


    return 0;
}

