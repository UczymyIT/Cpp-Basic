#include <iostream>

using namespace std;
float obliczBMI(float waga, float wzrost)
{
    return waga/(wzrost*wzrost);
}

int zinterpretujWynikiBMI(float bmi)
{
    cout << "Twoje BMI wynosi: " << bmi << endl;
    if(bmi<16)
        cout << "Twoj wynik oznacza wyglodzenie.";
    else if(bmi >= 16 && bmi < 17)
        cout << "Twoj wynik oznacza wychudzenie.";
    else if(bmi >= 17 && bmi < 18.5)
        cout << "Twoj wynik oznacza niedowage.";
    else if(bmi >= 18.5 && bmi < 25)
        cout << "Twoj wynik oznacza prawidlowa wage.";
    else if(bmi >= 25 && bmi < 30)
        cout << "Twoj wynik oznacza nadwage.";
    else if(bmi >= 30 && bmi < 35)
        cout << "Twoj wynik oznacza I stopien otylosci.";
    else if(bmi >= 35 && bmi <= 40)
        cout << "Twoj wynik oznacza II stopien otylosci.";
    else if(bmi > 40)
        cout << "Twoj wynik oznacza III stopien otylosci";
}
int ktoryPoziom(float bmi)
{
    if(bmi<16)
        return -3;
    else if(bmi >= 16 && bmi < 17)
        return -2;
    else if(bmi >= 17 && bmi < 18.5)
        return -1;
    else if(bmi >= 18.5 && bmi < 25)
        return 0;
    else if(bmi >= 25 && bmi < 30)
        return 1;
    else if(bmi >= 30 && bmi < 35)
        return 2;
    else if(bmi >= 35 && bmi <= 40)
        return 3;
    else if(bmi > 40)
        return 4;
}

float jakaWagaGora(float waga, float wzrost, float bmi)
{
    int poziom = ktoryPoziom(bmi);
    int nowyPoziom = 0;
    float noweBMI = 0;
    do{
        waga = waga + 0.1;
        noweBMI = obliczBMI(waga,wzrost);
        nowyPoziom = ktoryPoziom(noweBMI);
    }while(poziom == nowyPoziom);

    return waga;
}

float jakaWagaDol(float waga, float wzrost, float bmi)
{
    int poziom = ktoryPoziom(bmi);
    int nowyPoziom = 0;
    float noweBMI = 0;
    do{
        waga = waga - 0.1;
        noweBMI = obliczBMI(waga,wzrost);
        nowyPoziom = ktoryPoziom(noweBMI);
    }while(poziom == nowyPoziom);
    return waga;
}

int main()
{
    cout << "Podaj wage w kilogramach: ";
    float waga;
    cin >> waga;
    cout << "Podaj wzrost w metrach: ";
    float wzrost;
    cin >> wzrost;

    float bmi = obliczBMI(waga,wzrost);
    zinterpretujWynikiBMI(bmi);
    int poziom = ktoryPoziom(bmi);
    cout << endl << "Poziom: " << poziom;
    if(poziom < 0)
        cout << endl << "Musisz przybrac na wadze. Kolejny poziom rozpoczyna sie od wagi:" << jakaWagaGora(waga,wzrost,bmi);
    if(poziom > 0)
        cout << endl << "Musisz zredukowac wage. Kolejny poziom rozpoczyna sie od wagi:" << jakaWagaDol(waga,wzrost,bmi);
    if(poziom == 0)
        cout << endl << "Nie musisz nic robic.";
    return 0;
}
