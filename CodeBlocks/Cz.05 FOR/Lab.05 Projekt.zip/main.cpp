#include <iostream>
using namespace std;

int main()
{
    int liczba, suma;
    cout << "Podaj liczbe dodatnia: ";
    cin >> liczba;

    for(int i=1 ; i <= liczba ; i++){
        suma = suma + i;
    }

    cout << "Suma = " << suma << endl;

    return 0;
}

