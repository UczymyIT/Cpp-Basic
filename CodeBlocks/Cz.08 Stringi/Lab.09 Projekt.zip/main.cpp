#include <iostream>

using namespace std;

int main()
{
    string zdanie = "Ala ma kota Bonifacego i psa Pankracego.";
    string wyraz = zdanie.substr(12,10);
    cout << "Zdanie: " << zdanie << endl;
    cout << "Wyraz: " << wyraz;
    return 0;
}
