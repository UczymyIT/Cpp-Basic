#include <iostream>
using namespace std;

int main()
{
    cout << "Podaj swoje imie: ";
    string imie;
    cin >> imie;
    int dlugoscStringa = imie.length();
    if(imie[dlugoscStringa-1] == 'a')
        cout << "Prawdopodobnie jestes kobieta!";
    else
        cout << "Prawdopodobnie jestes facetem!";

    return 0;
}
