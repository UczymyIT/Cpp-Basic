#include <iostream>
#include <string>
using namespace std;

int main()
{
    string str1 = "Ala ma ";
    string str2 = "kota.";
    string wynik = str1 + str2;
    cout << wynik;

    return 0;
}
