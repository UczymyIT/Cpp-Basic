#include <iostream>

using namespace std;

int main()
{
    string zdanie = "Ala ma kota.";
    zdanie.insert(11," Filemona i psa Pankracego");
    cout << zdanie;
    return 0;
}
