#include <iostream>

using namespace std;

int main()
{
    string zdanie = "Ala ma kota Filemona i psa Pankracego.";
    zdanie.replace(12,8,"Bonifacego");
    cout << zdanie;
    return 0;
}
