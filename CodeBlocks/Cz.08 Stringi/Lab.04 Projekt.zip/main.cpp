#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int main()
{
    string zdanie = "Ala ma kota";

    transform(zdanie.begin() , zdanie.end() , zdanie.begin() , ::toupper);
    cout << zdanie << endl;

    transform(zdanie.begin() , zdanie.end() , zdanie.begin() , ::tolower);
    cout << zdanie << endl;

    return 0;
}
