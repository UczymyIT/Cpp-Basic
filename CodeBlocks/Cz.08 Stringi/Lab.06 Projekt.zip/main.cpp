#include <iostream>

using namespace std;

int main()
{
    string zdanie = "Ala ma kota";
    cout << "Oryginalne zdanie: " << zdanie << endl;
    zdanie.erase(7,4);
    cout << "Zdanie po usunieciu slowa kota: " << zdanie;

    return 0;
}
