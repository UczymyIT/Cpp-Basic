#include <iostream>
#include <string>
using namespace std;

int main()
{
    string zdanie;
    cout << "Napisz zdanie: ";
    getline(cin,zdanie);

    string fraza;
    cout << "Podaj szukana freze: ";
    getline(cin,fraza);

    size_t index_pozycji = zdanie.find(fraza);
    if(index_pozycji != string::npos)
        cout << "Jest, znalazlem fraze na pozycji (index):" << index_pozycji;
    else
        cout << "Przykro mi, nie znalazlem szukanej frazy";
    return 0;
}
