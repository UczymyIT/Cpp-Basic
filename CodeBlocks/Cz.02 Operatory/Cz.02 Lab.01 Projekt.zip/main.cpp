#include <iostream>

using namespace std;

int main()
{
    cout << "To jest test dodawania: 2+2 = " << 2+2 << endl;
    cout << "To jest test odejmowania: 5-2 = " << 5-2 << endl;
    cout << "To jest test mnozenia: 3*3 = " << 3*3 << endl;
    cout << "To jest test dzielenia: 10/2 = " << 10/2 << endl;
    // modulo to reszta z dzielenia
    cout << "To jest test modulo: 15%2 = " << 15%2 << endl;

    return 0;
}
