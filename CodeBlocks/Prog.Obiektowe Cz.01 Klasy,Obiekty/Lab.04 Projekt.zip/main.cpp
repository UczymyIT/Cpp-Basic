#include <iostream>
#include <fstream>

using namespace std;

class Zwierze
{
    public:
        string gromada;
        string rzad;
        string rodzina;
        string gatunek;
        int wiek;
        float waga;
        float dlugosc;
        float szerokosc;
        float wysokosc;

    void wpiszDane()
    {
        cout << "Funkcja: wpisz dane.";

        cout << endl << "Podaj gromade: ";  cin >> gromada;
        cout << "Podaj rzad: ";     cin >> rzad;
        cout << "Podaj rodzine: ";  cin >> rodzina;
        cout << "Podaj gatunek: ";  cin >> gatunek;
        cout << "Podaj wiek: ";     cin >> wiek;
        cout << "Podaj wage: ";     cin >> waga;
        cout << "Podaj dlugosc: ";  cin >> dlugosc;
        cout << "Podaj szerokosc: ";cin >> szerokosc;
        cout << "Podaj wysokosc: "; cin >> wysokosc;
    }
    void wypiszDane()
    {
        cout << endl << endl << "Funkcja: wypisz dane." << endl;

        cout << "Gromada: " << gromada << endl;
        cout << "Rzad: " << rzad << endl;
        cout << "Rodzina: " << rodzina << endl;
        cout << "Gatunek: " << gatunek << endl;
        cout << "Wiek: " << wiek << endl;
        cout << "Waga: " << waga << endl;
        cout << "Dlugosc: " << dlugosc << endl;
        cout << "Szerokosc: " << szerokosc << endl;
        cout << "Wysokosc: " << wysokosc << endl;
    }

    void zapiszDane()
    {
        fstream plik;
        plik.open("zoo.txt", ios::out | ios::app);
        plik << endl << "Gromada: " << gromada << endl;
        plik << "Rzad: " << rzad << endl;
        plik << "Rodzina: " << rodzina << endl;
        plik << "Gatunek: " << gatunek << endl;
        plik << "Wiek: " << wiek << endl;
        plik << "Waga: " << waga << endl;
        plik << "Dlugosc: " << dlugosc << endl;
        plik << "Szerokosc: " << szerokosc << endl;
        plik << "Wysokosc: " << wysokosc << endl;
        plik << "----------------------------";
        plik.close();
    }


};
int main()
{
    Zwierze zwierze;
    zwierze.wpiszDane();
    zwierze.wypiszDane();
    zwierze.zapiszDane();
    return 0;
}
