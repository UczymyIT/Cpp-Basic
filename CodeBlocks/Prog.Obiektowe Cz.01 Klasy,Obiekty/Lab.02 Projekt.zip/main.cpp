#include <iostream>

using namespace std;

class Pokoj
{
    public:
        double szerokosc;
        double dlugosc;
        double wysokosc;
};

int main()
{
    Pokoj pokoj;
    pokoj.szerokosc = 2.3;
    pokoj.dlugosc = 3.2;
    pokoj.wysokosc = 4.4;

    cout << "Wymiary pokoju to: ";
    cout << endl << "dlugosc = " << pokoj.dlugosc;
    cout << endl << "szerokosc = " << pokoj.szerokosc;
    cout << endl << "wysokosc = " << pokoj.wysokosc;

    return 0;
}
