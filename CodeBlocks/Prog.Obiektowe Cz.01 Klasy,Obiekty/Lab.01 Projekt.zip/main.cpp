/*-------------------------------------------------------
Napisz program:
* stworz klase Auto
* przypisz do niej cechy auta
* w programie glownym stworz obiekt: maluch
* przypisz warto�ci do cech obiektu maluch
* wyswietl cechy na ekranie
-------------------------------------------------------*/
#include <iostream>

using namespace std;

class Auto
{
    public:
        string nrrejestracyjny;
        string kolor;
        string typ;
        int rocznik;
        int pojemnosc;
};

int main()
{
    Auto maluch;
    maluch.nrrejestracyjny = "RP12345";
    maluch.kolor = "zolty";
    maluch.typ = "miejskie";
    maluch.rocznik = 1990;
    maluch.pojemnosc = 900;

    cout << "Numer rejestracyjny: " << maluch.nrrejestracyjny << endl;
    cout << "Kolor: " << maluch.kolor << endl;
    cout << "Typ nadwozia: " << maluch.typ << endl;
    cout << "Rocznik : " << maluch.rocznik << endl;
    cout << "Pojemnosc : " << maluch.pojemnosc << endl;

    return 0;
}
