#include <iostream>

using namespace std;

class Pokoj
{
    public:
        double szerokosc;
        double dlugosc;
        double wysokosc;

    double obliczPolePokoju() {
        return szerokosc * dlugosc;
    }

    double obliczObjetoscPokoju() {
        return szerokosc * wysokosc * wysokosc;
    }
};

int main()
{
    Pokoj pokoj1;
    pokoj1.szerokosc = 2.3;
    pokoj1.dlugosc = 3.2;
    pokoj1.wysokosc = 4.4;

    cout << "Wymiary pokoju to: ";
    cout << endl << "dlugosc = " << pokoj1.dlugosc;
    cout << endl << "szerokosc = " << pokoj1.szerokosc;
    cout << endl << "wysokosc = " << pokoj1.wysokosc;

    cout << endl << "Pole pokoju: " << pokoj1.obliczPolePokoju();
    cout << endl << "Objetosc pokoju: " << pokoj1.obliczObjetoscPokoju();

    return 0;
}
