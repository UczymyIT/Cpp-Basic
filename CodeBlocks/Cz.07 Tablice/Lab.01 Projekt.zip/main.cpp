#include <iostream>

using namespace std;

int main()
{
    int tab[6] = {44,12,55,60,47,1};

    cout << tab[16];

    return 0;
}

