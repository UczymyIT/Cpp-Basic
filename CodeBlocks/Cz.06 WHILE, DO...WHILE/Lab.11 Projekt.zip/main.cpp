#include <iostream>

using namespace std;

int main()
{

    int liczba;
    int flaga = 0;

    do
    {
        if (flaga == 0){
            cout << "Podaj liczbe dodatnia : ";
            flaga = 1;
        }
        else{
            cout << endl << "Podaj liczbe dodatnia : ";
        }

        cin >> liczba;

        if(liczba <= 0 )
        {
            cout << "Podales liczbe ujemna lub rowna 0! ";
        }
        else
        {
            cout << "Twoja liczba jest poprawna, wieksza od 0. Konczymy program.";
        }
    }
    while(liczba <= 0 );
    return 0;
}

