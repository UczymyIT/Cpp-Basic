#include <iostream>
using namespace std;

int main()
{
    int liczba, suma, i;
    cout << "Podaj liczbe dodatnia: ";
    cin >> liczba;

    suma = 0;
    i = 1;
    while(i <= liczba){
        suma = suma + i;
        //suma += i;
        i++;
    }

    cout << "Suma = " << suma << endl;

    return 0;
}

