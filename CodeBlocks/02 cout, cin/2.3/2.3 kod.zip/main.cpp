#include <iostream>

using namespace std;

int main()
{
    string imie;
    int liczba;
    cout << "Podaj swoje imie: " ;
    cin >> imie;
    cout << "Ile masz lat: " ;
    cin >> liczba;
    cout << "Czesc " << imie
        << " , milo Cie poznac. Masz "
        << liczba << " lat." << endl;

    return 0;
}

