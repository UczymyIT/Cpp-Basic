// dolaczenie biblioteki iostream
#include <iostream>

// wskazanie na uzycie przestrzeni nazw std
using namespace std;

// poczatek programu -> funkcja main()
int main()
{
    cout << "Jak masz na imie: ";
    string imie;
    cin >> imie;

    cout << "Czesc " << imie << " milo Cie poznac :)" ;

    return 0;
}



