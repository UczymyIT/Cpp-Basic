#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj dzien tygodnia: " ;
    int dzien;
    cin >> dzien;

    switch (dzien) {
      case 1:
        cout << "Poniedzielek";
        break;
      case 2:
        cout << "Wtorek";
        break;
      case 3:
        cout << "Sroda";
        break;
      case 4:
        cout << "Czwartek";
        //cout << endl << "Pamietaj masz karate!";
        //cout << endl << "Pamietaj idz do sklepu";
        break;
      case 5:
        cout << "Piatek";
        break;
      case 6:
        cout << "Sobota";
        break;
      case 7:
        cout << "Niedziela";
        break;
    }

    return 0;
}
