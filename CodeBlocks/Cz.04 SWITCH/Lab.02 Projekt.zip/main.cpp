#include <iostream>

using namespace std;

int main()
{

    cout << "Podaj numer pietra: " ;
    int pietro;
    cin >> pietro;

    switch (pietro) {
      case 1:
        cout << "Jestes na 1 pietrze";
        break;
      case 2:
        cout << "Jestes na 2 pietrze";
        break;
      case 3:
        cout << "Jestes na 3 pietrze";
        break;
      case 4:
        cout << "Jestes na 4 pietrze";
        break;
      case 5:
        cout << "Jestes na 5 pietrze";
        break;
      case 6:
        cout << "Jestes na 6 pietrze";
        break;
      case 7:
        cout << "Jestes na 7 pietrze";
        break;
    case 8:
        cout << "Jestes na 8 pietrze";
        break;
    case 9:
        cout << "Jestes na 9 pietrze";
        break;
    case 10:
        cout << "Jestes na 10 pietrze";
        break;
    default:
        cout << "Blad odczytu. Nie ma takiego pietra";
        break;
    }

    return 0;
}
