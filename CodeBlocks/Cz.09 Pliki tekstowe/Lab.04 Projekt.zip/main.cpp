#include <iostream>
#include <fstream>
#include <cstdlib>
#include <algorithm>
#include <string>

using namespace std;

int main()
{
    string tytul, autor;
    string pytania[5];
    string odpA[5], odpB[5], odpC[5], poprawna[5];
    string odpowiedz;
    int punkty=0;

    string linia;
    int licznik=1;
    int pytanie=0;

    fstream plik;
    plik.open("quiz.txt", ios::in);
    if(plik.good()==false){
        cout << "Nie moglem otworzyc pliku!";
        exit(0);
    }
    //else
    //    cout << "Plik jest!";
    while(getline(plik,linia)){
        switch(licznik)
        {
            case 1: tytul = linia; break;
            case 2: autor = linia; break;
            case 3: pytania[pytanie] = linia; break;
            case 4: odpA[pytanie] = linia; break;
            case 5: odpB[pytanie] = linia; break;
            case 6: odpC[pytanie] = linia; break;
            case 7: poprawna[pytanie] = linia; break;
        }
        if(licznik == 7){
            licznik = 2;
            pytanie++;
        }
        licznik++;
    }
    plik.close();

    for(int i=0 ; i<=4 ; i++) {
        cout << endl << pytania[i] << endl;
        cout << odpA[i] << endl;
        cout << odpB[i] << endl;
        cout << odpC[i] << endl;
        cout << "Podaj prawidlowa odpowiedz: ";
        cin>> odpowiedz;
        transform(odpowiedz.begin(),odpowiedz.end(), odpowiedz.begin(), ::tolower);
        if(odpowiedz==poprawna[i]){
            cout << "Brawo! Dostajesz 1 punkt.";
            punkty++;
        }
        else {
            cout << "Niestety bledna odpowiedz. Brak punktow.";
        }
        cout << endl;

    }
    cout << endl << "Koniec. Zdobyte punkty: " << punkty << " na 5 mo�liwych.";
    return 0;
}
