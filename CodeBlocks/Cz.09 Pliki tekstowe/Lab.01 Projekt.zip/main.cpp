#include <iostream>
#include <fstream>


using namespace std;

int main()
{
    string imie, nazwisko, mail;
    int telefon;
    cout << "Podaj imie: " ;
    cin >> imie;
    cout << "Podaj nazwisko: " ;
    cin >> nazwisko;
    cout << "Podaj nr. telefonu: " ;
    cin >> telefon;
    cout << "Podaj maila: " ;
    cin >> mail;
    fstream plik;

    plik.open("test.txt", ios::out);

    plik << imie << endl;
    plik << nazwisko << endl;
    plik << telefon << endl;
    plik << mail << endl;

    plik.close();

    return 0;
}
