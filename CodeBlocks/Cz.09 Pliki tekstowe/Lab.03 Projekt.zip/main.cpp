#include <iostream>
#include <fstream>
#include <cstdlib>


using namespace std;

int main()
{
    fstream plik;
    string imie,nazwisko,mail;
    int telefon;

    plik.open("test.txt", ios::in);

    if(plik.good()==false){
        cout << "Plik nie istnieje!";
        exit(0);
    }

    string zmienna;
    int licznik = 1;
    while(getline(plik,zmienna)){
        switch(licznik)
        {
            case 1: imie = zmienna; break;
            case 2: nazwisko = zmienna; break;
            case 3: telefon = atoi(zmienna.c_str()); break;
            case 4: mail = zmienna; break;
        }

        licznik++;
    }
    plik.close();
    cout << imie << endl << nazwisko << endl;
    cout << telefon << endl << mail << endl;
    return 0;
}
