#include <iostream> // dolaczenie biblioteki iostream

using namespace std; // wskazanie na uzycie przestrzeni nazw std

int main() // poczatek programu -> funkcja main()
{
    cout << "Hello world!" << endl; // przeslanie na ekran tekstu "Hello world!" za pomoca funkcji cout
    return 0;
}
