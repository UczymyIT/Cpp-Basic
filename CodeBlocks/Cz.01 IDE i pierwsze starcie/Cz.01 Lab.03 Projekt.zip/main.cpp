#include <iostream>

using namespace std;

int main()
{
    cout << "Podaj swoje imie: ";
    string imie;
    cin >> imie;
    cout << "Podaj swoj wiek: ";
    int wiek;
    cin >> wiek;
    cout << "Czesc " << imie << " milo Cie poznac. Widze ze masz " << wiek << " lat.";
    return 0;
}
