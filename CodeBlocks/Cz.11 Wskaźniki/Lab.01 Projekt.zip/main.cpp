#include <iostream>

using namespace std;

int main()
{
    int liczba = 4;
    int *w_int = &liczba;
    string tekst = "Reksio to najlepszy pies na swiecie.";
    string *w_string = &tekst;
    bool buul = false;
    bool *w_bool = &buul;

    cout << "w_int = " << w_int ;
    cout << endl << "*w_int = " << *w_int ;
    cout << endl <<  "w_string = " << w_string ;
    cout << endl <<  "*w_string = " << *w_string ;
    cout << endl <<  "w_bool = " << w_bool ;
    cout << endl <<  "*w_bool = " << *w_bool ;

    return 0;
}

