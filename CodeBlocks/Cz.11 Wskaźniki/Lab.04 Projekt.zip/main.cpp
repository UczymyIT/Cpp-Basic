#include <iostream>
using namespace std;

int main()
{
    int tab[5], i, suma = 0;
    int *wsk, *wsk2;

    cout << "Podaj 5 liczb: " << endl ;
    for (i = 0; i < 5; i++) {
        cin >> tab[i];
    }

    wsk = tab;
    for (i = 0; i < 5; i++) {
        suma = suma + *(wsk + i);
    }

    cout << endl << "Suma elementow tablicy: " << suma;

    return 0;

}
