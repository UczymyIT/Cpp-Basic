#include <iostream>
using namespace std;

int main() {

    int liczba1, liczba2, *wsk1, *wsk2, suma = 0;
    cout << "Podaj 2 liczby calkowite: " << endl;
    cin >> liczba1 >> liczba2;
    wsk1 = &liczba1;
    wsk2 = &liczba2;
    suma = *wsk1 + *wsk2;
    cout << "Suma dwoch podanych liczb to: " << suma;

    return 0;

}
