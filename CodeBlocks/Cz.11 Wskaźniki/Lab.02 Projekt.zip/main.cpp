#include <iostream>

using namespace std;

int main()
{
    int liczba = 4;
    cout << "Podaj liczbe: " << liczba;
    int *wsk;
    wsk = &liczba;
    cout << endl << "Wskaznik (wsk): " << wsk;
    cout << endl <<  "Wartosc na ktora wskazuje wskaznik (*wsk): " << *wsk;
    *wsk = 8;

    cout << endl <<  "Liczba po przypisaniu wartosci poprzez *wsk = 8: " << liczba;
    return 0;
}
