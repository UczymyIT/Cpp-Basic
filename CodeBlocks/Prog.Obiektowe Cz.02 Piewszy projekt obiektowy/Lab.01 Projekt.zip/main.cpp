#include <iostream>
#include "Pytanie.h"
using namespace std;

int main()
{
    int suma = 0;

    Pytanie p[5];
    for(int i = 0 ; i <= 4 ; i++)
    {
        p[i].nr_pytania = i+1;
        p[i].wczytajDanezPliku();
        p[i].pokazPytanie();
        p[i].zliczPunkty();
        suma += p[i].liczbaPunktow;
    }
    cout << "Zdobyles: " << suma;


    return 0;
}
