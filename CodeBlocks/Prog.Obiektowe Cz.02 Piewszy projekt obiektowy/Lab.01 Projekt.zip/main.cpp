#include <iostream>
#include "Pytanie.h"
using namespace std;

int main()
{
    Pytanie p1;
    p1.nr_pytania = 2;
    p1.wczytajDanezPliku();
    p1.pokazPytanie();
    p1.zliczPunkty();
    //cout << p1.odpPoprawna;
    cout << p1.liczbaPunktow;

    return 0;
}
