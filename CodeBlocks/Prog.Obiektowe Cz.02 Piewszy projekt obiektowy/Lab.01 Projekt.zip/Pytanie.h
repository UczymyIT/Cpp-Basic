#include <iostream>
using namespace std;

class Pytanie
{
    public:
        string tresc;
        string odpA, odpB, odpC;
        string odpPoprawna;
        string odpUzytkownika;
        int liczbaPunktow;
        int nr_pytania;

        // wczytuje dane z pliku tekstowego
        void wczytajDanezPliku();

        // pokazuje pytania na ekranie
        void pokazPytanie();

        // zlicza punkty uzyskane przez uzytkownika
        void zliczPunkty();

};
