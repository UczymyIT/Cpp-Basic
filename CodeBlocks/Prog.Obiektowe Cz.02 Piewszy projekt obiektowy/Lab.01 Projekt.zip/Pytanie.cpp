#include <iostream>
#include "Pytanie.h"
#include <fstream>

using namespace std;

void Pytanie::wczytajDanezPliku()
{
    fstream plik;
    plik.open("quiz.txt",ios::in);
    if(plik.good()==false)
    {
        cout << "Nie moge otworzyc pliku. Program zostanie zamkniety.";
        exit(0);
    }
    int nr_linii = (nr_pytania-1) * 5 +1;
    int licznik = 1;
    string linia;
    while(getline(plik,linia))
    {
        if(licznik == nr_linii) tresc = linia;
        if(licznik == nr_linii+1) odpA = linia;
        if(licznik == nr_linii+2) odpB = linia;
        if(licznik == nr_linii+3) odpC = linia;
        if(licznik == nr_linii+4) odpPoprawna = linia;
        licznik++;
    }
    plik.close();
}

void Pytanie::pokazPytanie()
{
    cout << endl << tresc << endl;
    cout << odpA << endl;
    cout << odpB << endl;
    cout << odpC << endl;
    cout << "Podaj odpowiedz: ";
    cin >> odpUzytkownika;
}

void Pytanie::zliczPunkty()
{
    if(odpUzytkownika == odpPoprawna)
        liczbaPunktow = 1;
    else
        liczbaPunktow = 0;
}
