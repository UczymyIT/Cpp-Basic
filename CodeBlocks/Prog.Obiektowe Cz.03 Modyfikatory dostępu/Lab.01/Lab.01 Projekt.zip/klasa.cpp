#include <iostream>
#include "klasa.h"
using namespace std;



void Auto::wpiszMarke(string argMarka)
    {
        marka = argMarka;
        cout << marka;
    }

void Auto::obliczZasieg()
    {
        // cialo metody
    }
