#include <iostream>
#include "klasa.h"
#include "przycisk.h"
using namespace std;

int main()
{
    Auto auto1;
    //auto1.marka = "Opel";
    auto1.wpiszMarke("Opel");

    return 0;
}
