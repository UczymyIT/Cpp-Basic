#include <iostream>
using namespace std;

class Auto
{
    private:
    string marka;
    string model;

    public:
    void wpiszMarke(string argMarka);
    void obliczZasieg();

};
